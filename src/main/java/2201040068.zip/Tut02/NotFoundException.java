package Tut02;

public class NotFoundException extends Exception{
    public NotFoundException(String mess){
        super(mess);
    }
}
